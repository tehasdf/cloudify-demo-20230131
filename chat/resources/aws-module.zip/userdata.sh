#!/bin/bash -v
sudo yum install -y gcc
